<?php
	class Conn{
		// ATTRIBUTES
		private $db;
		private $conn;
		private $controller_db = 'mysql';
		private $host_db       = 'localhost';
		private $user_db       = 'root';
		private $pass_db       = '';

		// CONSTRUCTOR
		public function __construct($db){
			$this->db = $db;
			$this->conn();
		}

		// METHODS
		private function conn(){
			try{ 
				$this->conn = new PDO("$this->controller_db:host=$this->host_db;dbname=$this->db;", "$this->user_db", "$this->pass_db");
				$this->conn -> setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
				return true;
			}catch(PDOException $e){
				return $e -> getMessage();
			}
		}
		
		public function begin(){
			try{
				$sql = $this->conn->query('BEGIN');
				return true;
			}catch(PDOException $e){
				return $e -> getMessage();
			}
		}

		public function sql($query, $data = array()){
			try{
				$sql = $this->conn->prepare($query);
				$res = $sql->execute($data);
				if(substr($query, 0, 6) == 'SELECT' || substr($query, 0, 6) == 'select' || stripos($query, 'returning') !== false){
					$res = $sql->fetchAll();
					return $res;
				}
				return $sql->rowCount();
			}catch(PDOException $e){
				return $e -> getMessage();
			}
		}

		public function commit(){
			try{
				$sql = $this->conn->query('COMMIT');
				return true;
			}catch(PDOException $e){
				return $e -> getMessage();
			}
		}

		public function rollback(){
			try{
				$sql = $this->conn->query('ROLLBACK');
				return true;
			}catch(PDOException $e){
				return $e -> getMessage();
			}
		}

		public function close(){
			$this->conn = null;
		}

		public function setController($controller_db){
			$this->controller_db = $controller_db;
		}

		public function setDb($db){
			$this->db = $db;
		}

		private function setHost($host_db){
			$this->host_db = $host_db;
		}

		private function setPort($port_db){
			$this->port_db = $port_db;
		}

		private function setUser($user_db){
			$this->user_db = $user_db;
		}

		private function setPass($pass_db){
			$this->pass_db = $pass_db;
		}

		public function getController($controller_db){
			return $this->controller_db;
		}

		public function getDb(){
			return $this->db;
		}
	}
?>
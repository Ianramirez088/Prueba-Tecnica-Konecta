<?php
	header('Access-Control-Allow-Origin: *');
	header('Content-Type: application/json');
	header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE");
	header("Allow: GET, POST, PUT, DELETE");
	header("Access-Control-Allow-Headers: Content-Type, Accept");


	require_once '../Repositories/show.php';
	require_once '../Repositories/insert.php';
	require_once '../Repositories/update.php';
	require_once '../Repositories/delete.php';
	require_once './conn.php';

	class Router
	{
		private array $response = [];
		private show $index;
		private store $store;
		private delete $delete;
		private update $update;
		private $db;

		public function __construct()
		{
			$this->db = new Conn('inventory');
			$this->index = new Show($this->db);
			$this->store = new Store($this->db);
			$this->delete = new Delete($this->db);
			$this->update = new Update($this->db);
			$this->execute();
		}

		private function execute() : void
		{
			switch ($_SERVER['REQUEST_METHOD']) {
				case 'GET':
					$this->response = $this->index->show($_GET);
					break;
				case 'POST':
					$_POST = json_decode(file_get_contents('PHP://input'), true);
					$this->response = $this->store->stores($_POST);
					break;
				case 'PUT':
					$_PUT = json_decode(file_get_contents('PHP://input'), true);
					$this->response = $this->update->update($_PUT);	
					break;
				case 'DELETE':
					$_DELETE = json_decode(file_get_contents('PHP://input'), true);
					$this->response = $this->delete->delete($_DELETE);	
					break;
			}

			echo json_encode($this->response, JSON_PRETTY_PRINT);
		}
	}

	new Router();
?>
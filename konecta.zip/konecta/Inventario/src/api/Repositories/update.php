<?php
	class Update
	{
		private $conn;

		public function __construct($conn)
		{
			$this->conn = $conn;
		}

		public function update($item) : array
		{
			if(isset($item['op'])) {
				return $this->update_sale($item); 
			} else {
				return $this->update_product($item); 
			}
		}

		public function update_product($data) : array {
            $sql = "UPDATE products SET name = :nam, reference = :ref, price = :pri, weight = :wei, category = :cat, stock = :sto WHERE id = :id";
            $params = [
				'id' => $data['id'],
				'nam' => $data['name'],
				'ref' => $data['reference'],
				'pri' => $data['price'],
				'wei' => $data['weight'],
				'cat' => $data['category'],
				'sto' => $data['stock']
			];

			$res = $this->conn->sql($sql, $params);

            if($res > 0){
                return [ 'state' => 'OK', 'payload' => $res ];
            } else {
                return [ 'state' => 'NO', 'payload' => $res ];
            }
		}

		public function update_sale($data) : array {
            $sql = "UPDATE sales SET quantity = quantity + :qua WHERE id = :id";
            $params = [
				'id' => (int) $data['id'],
				'qua' => (int) $data['quantity']
			];

			$res = $this->conn->sql($sql, $params);
			
            if($res > 0){
                return [ 'state' => 'OK', 'payload' => $res ];
            } else {
                return [ 'state' => 'NO', 'payload' => $res ];
            }
		}
	}
?>
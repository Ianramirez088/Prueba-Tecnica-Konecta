<?php
	class Delete
	{
		private $conn;

		public function __construct($conn)
		{
			$this->conn = $conn;
		}

		public function delete($item) : array
		{
			return $this->delete_product($item['id']);  
		}

		private function delete_product($id){
            $sql = "DELETE FROM products WHERE id = :id";
            $params = [ 'id' => $id ];
			$res = $this->conn->sql($sql, $params);

            if($res > 0){
                return [ 'state' => 'OK', 'payload' => $res ];
            } else {
                return [ 'state' => 'NO', 'payload' => $res ];
            }
		}
		
	}
?>
<?php

	class Store
	{
		private $conn;

		public function __construct($conn)
		{
			$this->conn = $conn;
		}

		public function stores($item) : array
		{
			if(isset($item['op'])) {
				return $this->save_sale($item);
			} else {
				return $this->save_product($item); 
			}
		}

		public function save_product($data) : array {
            $sql = "INSERT INTO products(id, name, reference, price, weight, category, date_create, stock) VALUES(DEFAULT, :nam, :ref, :pri, :wei, :cat, :dat, :sto)";
            $params = [
				'nam' => $data['name'],
				'ref' => $data['reference'],
				'pri' => $data['price'],
				'wei' => $data['weight'],
				'cat' => $data['category'],
				'dat' => $data['date'],
				'sto' => $data['stock']
			];

			$res = $this->conn->sql($sql, $params); 
            if($res > 0){
                return [ 'state' => 'OK', 'payload' => $res ];
            } else {
                return [ 'state' => 'NO', 'payload' => $res ];
            }
		}

		public function save_sale($data) : array {
            $sql = "INSERT INTO sales(id, value, quantity, date_create) VALUES(:id, :val, :qua, NOW())";
            $params = [
				'id' => $data['id'],
				'val' => $data['price'],
				'qua' => $data['quantity']
			];

			$res = $this->conn->sql($sql, $params); 

            if($res > 0){
                return [ 'state' => 'OK', 'payload' => $res ];
            } else {
                return [ 'state' => 'NO', 'payload' => $res ];
            }
		}
	}
?>
<?php
	class Show
	{
		private $conn;

		public function __construct($conn)
		{
			$this->conn = $conn;
		}

		public function show($item) : array
		{
			if($item['op'] == 'get_products') {
				return $this->get_information();
			} elseif($item['op'] == 'get_sales_product') {
				return $this->get_sales_product($item['id']);
			} elseif($item['op'] == 'get_stocks_products') {
				return $this->get_stocks_products();
			}
		}

		private function get_information() : array
		{
            $sql = "SELECT * FROM products";
            $params = [];

			$res = $this->conn->sql($sql, $params);

            if(is_array($res) && count($res) > 0){
                return [ 'state' => 'OK', 'payload' => $res ];
            } else {
                return [ 'state' => 'NO', 'payload' => $res ];
            }
		}

		private function get_sales_product($id) : array
		{
            $sql = "SELECT * FROM sales WHERE id = :id";
            $params = [ 'id' => $id ];

			$res = $this->conn->sql($sql, $params);
		
            if(is_array($res) && count($res) > 0){
                return [ 'state' => 'OK', 'payload' => $res ];
            } else {
                return [ 'state' => 'NO', 'payload' => $res ];
            }
		}

		private function get_stocks_products() : array
		{
            $sql = "SELECT b.id, b.name, b.stock - a.quantity AS stock, b.weight, b.price, b.category, b.reference,
							a.quantity
						FROM sales AS a
							INNER JOIN products AS b
								ON a.id = b.id";
            $params = [];

			$res = $this->conn->sql($sql, $params);
		
            if(is_array($res) && count($res) > 0){
                return [ 'state' => 'OK', 'payload' => $res ];
            } else {
                return [ 'state' => 'NO', 'payload' => $res ];
            }
		}
	}
?>
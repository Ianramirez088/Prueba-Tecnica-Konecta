"use strict";

import Container from "./components/Container.js";

const App = {
	name: "App",
	components: { Container },
	setup() {
	},
	/*html*/
	template: `
		<transition name="fade" mode="out-in" appear>
			<container />
		</transition>
	`,
};

export default App;

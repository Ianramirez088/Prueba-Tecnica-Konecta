"use strict";

const { useStore  } = Vuex;
const { computed } = Vue;

const ProductSaleWin = {
	name: "ProductSaleWin",
	setup() {
		const store = useStore();
        //vars
		let getProducts = computed(() => store.getters["getProducts"]("sale"))
	
		return { getProducts };
	},
	/*html*/
	template: `
		<table class="table table-bordered">
			<thead class="table-dark">
				<tr>
					<th><i class="fas fa-trophy"></i></th>
					<th>Nombre</th>
					<th>Referencia</th>
					<th>Valor</th>
					<th>Peso</th>
					<th>Categoria</th>
					<th>Ventas</th>
				</tr>
			</thead>
			<tbody>
				<tr class="table-primary">
					<th>{{ getProducts.id }}</th>
					<th>{{ getProducts.name }}</th>
					<th>{{ getProducts.reference }}</th>
					<th>{{ getProducts.price }}</th>
					<th>{{ getProducts.weight }}</th>
					<th>{{ getProducts.category }}</th>
					<th>{{ getProducts.quantity }}</th>
				</tr>
			</tbody>
		</table>		
    `
}

export default ProductSaleWin;
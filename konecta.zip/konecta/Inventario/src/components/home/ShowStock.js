"use strict";

const { useStore  } = Vuex;
const { toRef, ref, computed, onMounted, watchEffect } = Vue;

const ShowStock = {
	name: "ShowStock",
	setup() {
		const store = useStore();
        //vars
		let products = toRef(store.state, "products");
		let flag = toRef(store.state, "flag");
		//getters
		// let getvar = computed(() => store.getters["home/getvar"]);
		//commits
        // let commit = () => store.commit("home/commitfunc");
		//dispatch
        let deleteProduct = async (item) => await store.dispatch("deleteProduct", item);
		let updateProduct = async (item) => await store.dispatch("updateProduct", item);
		
        //component functions
        //return
		return { products, flag, deleteProduct, updateProduct };
	},
	/*html*/
	template: `
    	<div class="table-responsive m-3">
			<table class="table table-bordered">
				<thead class="table-dark">
					<tr>
						<th>#</th>
						<th>Nombre</th>
						<th>Referencia</th>
						<th>Precio</th>
						<th>Peso</th>
						<th>Categoria</th>
						<th>Existencias</th>
						<th>Acciones</th>
					</tr>
				</thead>
				<tbody>
					<tr v-for="(item, index) in products" :key="index">
						<td>{{ item.id }}</td>
						<td>
							<span v-if="!flag">{{ item.name }}</span>
							<input v-else v-model="item.name" type="text" class="form-control" placeholder="Nombre" />
						</td>
						<td>
							<span v-if="!flag">{{ item.reference }}</span>
							<input v-else v-model="item.reference" type="text" class="form-control" placeholder="Referencia" />
						</td>
						<td>
							<span v-if="!flag">{{ item.price }}</span>
							<input v-else v-model="item.price" type="number" class="form-control" placeholder="Precio" />
						</td>
						<td>
							<span v-if="!flag">{{ item.weight }}</span>
							<input v-else v-model="item.weight" type="number" class="form-control" placeholder="Peso" />
						</td>
						<td>
							<span v-if="!flag">{{ item.category }}</span>
							<input v-else v-model="item.category" type="text" class="form-control" placeholder="Categoria" />
						</td>
						<td>
							<span v-if="!flag">{{ item.stock }}</span>
							<input v-else v-model="item.stock" type="number" class="form-control" placeholder="Existencia" />
						</td>
						<td v-if="!flag" class="input-group">
							<button @click="flag = true;" class="btn btn-warning">
								<i class="fas fa-pencil"></i>
							</button>
							<button @click="deleteProduct(item.id)" class="btn btn-danger">
								<i class="fas fa-trash"></i>
							</button>
						</td>
						<td v-else>
							<div class="d-flex">
								<button @click="updateProduct(item);" class="btn btn-success">
									<i class="fas fa-check"></i>
								</button>
								<button @click="flag = false;" class="btn btn-danger">
									<i class="fa-solid fa-xmark"></i>
								</button>
							</div>
						</td>
					</tr>
				</tbody>
			</table>
		</div>
    `
}

export default ShowStock;
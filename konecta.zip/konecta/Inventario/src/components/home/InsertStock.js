"use strict";

const { useStore  } = Vuex;
const { toRef, ref, computed, onMounted, watchEffect } = Vue;

const InsertStock = {
	name: "InsertStock",
	setup() {
		const store = useStore();
        //vars
		let product = toRef(store.state, "product");
		let load = toRef(store.state, "load");
		let alert = toRef(store.state, "alert");
    	let saveProduct = async () => await store.dispatch("saveProduct");
		
		return { product, load, alert, saveProduct };
	},
	/*html*/
	template: `
		<form>
			<div class="row mb-3">
				<div class="col-4">
					<label for="nameProduct" class="form-label">Nombre del producto:</label>
					<input v-model="product.name" type="text" class="form-control" id="nameProduct" placeholder="Ingrese producto">
					<div class="form-text">Favor ingrese nombre del producto sin caracteres especiales.</div>
				</div>
				<div class="col-4">
					<label for="referenceProduct" class="form-label">Referencia del producto:</label>
					<input v-model="product.reference" type="text" class="form-control" id="referenceProduct" placeholder="Ingrese referencia">
				</div>
				<div class="col-4">
					<label for="priceProduct" class="form-label">Precio del producto:</label>
					<input v-model="product.price" type="number" class="form-control" id="priceProduct" placeholder="Ingrese cantidad">
				</div>
			</div>
			<div class="row mb-3">
				<div class="col-4">
					<label for="weigthProduct" class="form-label">Peso del producto:</label>
					<input v-model="product.weight" type="text" class="form-control" id="weigthProduct" placeholder="Ingrese peso">
				</div>
				<div class="col-4">
					<label for="categoryProduct" class="form-label">Categoria del producto:</label>
					<input v-model="product.category" type="text" class="form-control" id="categoryProduct" placeholder="Ingrese categoria">
				</div>
				<div class="col-4 mb-3">
					<label for="stockProduct" class="form-label">Existencias del producto:</label>
					<div class="d-flex btn-group">
						<input v-model="product.stock" type="text" class="form-control" id="stockProduct" placeholder="Ingrese existencia">
						<button @click="saveProduct" type="button" class="btn btn-success">
							<span v-if="!load">Guardar</span>
							<div v-else class="spinner-border text-light" role="status"></div>
						</button>
					</div>
				</div>
			</div>
		</form>
    `
}

export default InsertStock;
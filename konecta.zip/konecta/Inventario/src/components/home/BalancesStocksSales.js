"use strict";

const { useStore  } = Vuex;
const { ref } = Vue;

import ProductStockWin from './ProductStockWin.js'
import ProductSaleWin from './ProductSaleWin.js'

const BalancesStocksSales = {
	name: "BalancesStocksSales",
	components: { ProductStockWin, ProductSaleWin },
	setup() {
		const store = useStore();
        //vars
		let module = ref({
			sale: true,
			stock: false
		});
		
		return { module };
	},
	/*html*/
	template: `
		<table class="col-4 table table-hover">
			<tbody>
				<tr @click="module.sale = true; module.stock = false;">
					<td role="button">
						<i :class="module.sale ? 'fa-solid fa-folder-open mx-2 h6' : 'fa-solid fa-folder mx-2 h6'"></i>
						Producto mas vendido
					</td>
				</tr>
				<tr @click="module.sale = false; module.stock = true;">
					<td role="button">
						<i :class="module.stock ? 'fa-solid fa-folder-open mx-2 h6' : 'fa-solid fa-folder mx-2 h6'"></i>
						Producto con mas existencias
					</td>
				</tr>
			</tbody>
		</table>
		<product-stock-win v-if="module.stock" />
		<product-sale-win v-else-if="module.sale" />
    `
}

export default BalancesStocksSales;
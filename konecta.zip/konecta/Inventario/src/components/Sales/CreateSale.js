"use strict";

const { useStore  } = Vuex;
const { toRef, ref, computed, onMounted, watchEffect } = Vue;

const CreateSale = {
	name: "CreateSale",
	setup() {
		const store = useStore();
		//vars
		let stocksProducts = toRef(store.state, "stocksProducts");
		let flag = toRef(store.state, "flag");
		let sale = ref({
			id: 0,
			quantity: 1,
			price: 0,
		});
		let insertSale = async (data) => await store.dispatch("insertSale", data);
		
		let addShopping = (index, item, i) => {
			let totalValue = 0;
			if(index == 'add') {
				sale.value.quantity += 1;
			} else {
				sale.value.quantity -= 1;
			}

			totalValue = sale.value.quantity * stocksProducts.value[i].price
			sale.value.price = totalValue;
		}

		return { stocksProducts, flag, sale, addShopping, insertSale };
	},
	/*html*/
	template: `
		<div class="table-responsive m-3">
			<table class="table table-bordered">
				<thead class="table-dark">
					<tr>
						<th>#</th>
						<th>Nombre</th>
						<th>Referencia</th>
						<th>Valor</th>
						<th>Peso</th>
						<th>Categoria</th>
						<th>Existencias</th>
						<th v-if="flag">Cantidad</th>
						<th>Comprar</th>
					</tr>
				</thead>
				<tbody>
					<tr v-for="(item, index) in stocksProducts" :key="index">
						<td>{{ item.id }}</td>
						<td><span>{{ item.name }}</span></td>
						<td><span>{{ item.reference }}</span></td>
						<td>
							<span v-if="flag && item.id == sale.id">{{ sale.price }}</span>
							<span v-else-if="!flag">{{ item.price }}</span>
						</td>
						<td><span>{{ item.weight }}</span></td>
						<td><span>{{ item.category }}</span></td>
						<td><span>{{ item.stock }}</span></td>
						<td v-if="flag && item.id == sale.id" class="d-flex">
							<input v-model="sale.quantity" type="number" class="form-control" />
							<div class="btn-group">
								<button @click="addShopping('add', item, index);" class="btn btn-primary">
									<i class="fa-solid fa-plus"></i>
								</button>
								<button @click="addShopping('subtract', item, index);" class="btn btn-warning">
									<i class="fa-solid fa-minus"></i>
								</button>
							</div>
						</td>
						<td v-if="!flag" class="input-group">
							<button @click="flag = true; sale.id = item.id; sale.price = item.price;" class="btn btn-success">
								<i class="fa-sharp fa-solid fa-cart-plus"></i>
							</button>
						</td>
						<td v-if="flag && item.id == sale.id">
							<div class="btn-group">
								<button @click="insertSale({sale, product: item}); flag = false;" class="btn btn-success">
									<i class="fas fa-check"></i>
								</button>
								<button @click="flag = false;" class="btn btn-danger">
									<i class="fa-solid fa-xmark"></i>
								</button>
							</div>
						</td>
					</tr>
				</tbody>
			</table>
		</div>
	`
}

export default CreateSale;
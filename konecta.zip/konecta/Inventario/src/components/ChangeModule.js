"use strict";

const { toRef } = Vue;
const { useStore } = Vuex;

const ChangeModule = {
	name: "ChangeModule",
	setup() {
		const store = useStore();
		let module = toRef(store.state, "module");
		let searchProducts = async () => await store.dispatch("searchProducts");
		let searchStocksProducts = async () => await store.dispatch("searchStocksProducts");

		let setModule = (item) => store.commit("setModule", item);

		return { module, setModule, searchStocksProducts, searchProducts };
	},
	/*html*/
	template: `
		<div class="shadow mt-4 p-3 d-md-flex d-lg-flex">
			<div @click="setModule('create')"  role="button" class="card text-center flex-fill me-2 mb-3 mb-md-0 mb-lg-0" style="border-radius: .5rem;">
				<div class="color-card">
					<h4>Konecta</h4>
				</div>
				<div class="card-body card-body-1">
					<div class= "justify-content-start align-items-center" :class="screen <= 1200 ? '' : 'd-flex'">
						<img src="http://localhost/inventario/src/images/create.webp" class="img-card-income">
						<h5 class="card-title">Crear Producto</h4>
					</div>
				</div>
			</div>
			<div @click="setModule('read'); searchProducts();"  role="button" class="card text-center flex-fill me-2 mb-3 mb-md-0 mb-lg-0" style="border-radius: .5rem;">
				<div class="color-card">
					<h4>Konecta</h4>
				</div>
				<div class="card-body card-body-1">
					<div class= "justify-content-start align-items-center" :class="screen <= 1200 ? '' : 'd-flex'">
						<img src="http://localhost/inventario/src/images/read.jpg" class="img-card">
						<h5 class="card-title">Visualizar Productos</h4>
					</div>
				</div>
			</div>
			<div @click="setModule('sales'); searchStocksProducts();"  role="button" class="card text-center flex-fill me-2 mb-3 mb-md-0 mb-lg-0" style="border-radius: .5rem;">
				<div class="color-card">
					<h4>Konecta</h4>
				</div>
				<div class="card-body card-body-1">
					<div class= "justify-content-start align-items-center" :class="screen <= 1200 ? '' : 'd-flex'">
						<img src="http://localhost/inventario/src/images/sale.jpg" class="img-card">
						<h5 class="card-title">Ventas Productos</h4>
					</div>
				</div>
			</div>
			<div @click="setModule('balances'); searchStocksProducts();"  role="button" class="card text-center flex-fill me-2 mb-3 mb-md-0 mb-lg-0" style="border-radius: .5rem;">
				<div class="color-card">
					<h4>Konecta</h4>
				</div>
				<div class="card-body card-body-1">
					<div class= "justify-content-start align-items-center" :class="screen <= 1200 ? '' : 'd-flex'">
						<img src="http://localhost/inventario/src/images/balances.webp" class="img-card">
						<h5 class="card-title">Existencias vs Ventas</h4>
					</div>
				</div>
			</div>
		</div>
	`,
};

export default ChangeModule;

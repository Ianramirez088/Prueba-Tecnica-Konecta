"use strict";

const Container = {
	name: "Container",
	setup() {
	},
	/*html*/
	template: `
		<div class="mt-5">
			<router-view />
		</div>
	`,
};

export default Container;

"use strict";

const { createRouter, createMemoryHistory } = VueRouter;

import { app } from "../config.js";

const router = new createRouter({
	history: createMemoryHistory(`${app}/public/`),
	routes: [
		{
			path: "/",
			name: "Home",
			component: () => import("../views/Home.js"),
			meta: { requireAuth: false },
		}
	],
});

export default router;

"use strict";

export const app = "inventario";

export const api = `http://localhost/${app}/src/api`;

export const permissions = [
	{ identification: 0, area: '' },
]

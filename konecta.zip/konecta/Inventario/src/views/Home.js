"use strict";

const { toRef, watchEffect } = Vue
const { useStore } = Vuex

import InsertStock from '../components/home/InsertStock.js'
import ShowStock from '../components/home/ShowStock.js'
import CreateSale from '../components/Sales/CreateSale.js'
import BalancesStocksSales from '../components/home/BalancesStocksSales.js'
import ChangeModule from '../components/ChangeModule.js'

const Home = {
	name: "Home",
	components: { InsertStock, ShowStock, ChangeModule, CreateSale, BalancesStocksSales },
	setup() {
		const store = useStore();
		let module = toRef(store.state, "module");
		let alert = toRef(store.state, "alert");

		watchEffect(() => {
			if(alert.value.state) {
				setTimeout(() => {
					alert.value.state = false
					alert.value.message = ""
					alert.value.class = ''
				}, 3000)
			}
		})

		return { module, alert }
	},
	/*html*/
	template: `
		<div class="container">
			<div class="d-flex justify-content-center">
				<h1 class="text-success">Inventario y gestor de ventas</h1>
			</div>
			<hr>
			<change-module />
			<div class="card-content shadow-lg mt-4 p-5">
				<insert-stock v-if="module.create" />
				<show-stock v-else-if="module.read" />
				<create-sale v-else-if="module.sales" />
				<balances-stocks-sales v-else-if="module.balances" />
				<div v-if="alert.state" :class="alert.class" role="button">
					<i :class="alert.class == 'toast-danger' ? 'fa-solid fa-xmark fs-2 text-white m-2' : 'fa-solid fa-circle-check fs-2 text-white m-2'"></i>
					<span>{{ alert.message }}</span>
				</div>
			</div>
		</div>
	`,
};

export default Home;

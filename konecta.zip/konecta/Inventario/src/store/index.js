"use strict";

const { Store } = Vuex;

import { app, api } from "../config.js";

const hoy = moment().format("YYYY-MM-DD");

const store = new Store({
	state: () => ({
		app,
		module: {
			create: true,
			read: false,
			sales: false,
			balances: false
		},
		product: {
			name: '',
			reference: '',
			price: 0,
			weight: 0,
			category: '',
			stock: 0,
			date: hoy,
		},
		alert: {
			state: false, 
			message: '',
			class: ''
		},
		flag: false,
		update: false,
		products: [],
		stocksProducts: [],
		load: false
	}),
	mutations: {
		setModule(state, item) {
			for (const i in state.module) {
				state.module[i] = false;
				if(state.module[i] == state.module[item]) {
					state.module[item] = true;
				} else {
					state.module[i] = false;
				}
			}
		},

		setUpdate(state, item) {
			state.update = item
		},

		setAlert(state, data) {
			state.alert = data
		},

		setProducts(state, data) {
			state.products = data
		},

		setStocksProducts(state, data) {
			state.stocksProducts = data
		},

		setLoad(state) {
			state.load = !state.load
		},

		setFlag(state) {
			state.flag = false
		},

		emptyProduct(state) {
			state.product.name = '';
			state.product.reference = '';
			state.product.price = 0;
			state.product.weight = 0;
			state.product.category = '';
			state.product.stock = 0;
			state.product.date = hoy;
		},
	},
	actions: { 
		async saveProduct({ state, commit }) {
			commit('setLoad')

			let req = await fetch(`${api}/Routes/requests.php`, {
				method: 'POST',
				mode: 'cors',
				body: JSON.stringify(state.product)
			});

			req = await req.json();

			commit('setLoad');

			if(req.state == 'OK') {
				commit('setAlert', {
					state: true, 
					message: 'El producto se creo exitosamente',
					class: 'toast-success'
				});
				commit('emptyProduct');
			} else {
				commit('emptyProduct');
				commit('setAlert', {
					state: true,
					message: 'No se pudo crear el producto',
					class: 'toast-danger'
				});
			}
		},
		
		async insertSale({ state, commit, dispatch }, data) {
			await dispatch("searchSalesProduct", data.sale)

			commit('setLoad')
			data.sale.op = 'sale'
			let stock = +data.product.stock - +data.sale.quantity
			if(data.sale.quantity > 0) {
				if(!state.update) {
					if(stock >= 0) {
						let req = await fetch(`${api}/Routes/requests.php`, {
							method: 'POST',
							mode: 'cors',
							body: JSON.stringify(data.sale)
						});
			
						req = await req.json();
			
						commit('setLoad');
			
						if(req.state == 'OK') {
							commit('setAlert', {
								state: true, 
								message: 'La venta se generó exitosamente',
								class: 'toast-success'
							});
						} else {
							commit('setAlert', {
								state: true, 
								message: 'Error: No se pudo realizar la venta',
								class: 'toast-danger'
							});
							dispatch("searchStocksProducts")
						}
					} else {
						commit('setAlert', {
							state: true, 
							message: 'Error: No hay inventario disponible para la venta',
							class: 'toast-danger'
						});	
					}
				} else {
					dispatch("updateSale", data)
				}
			} else {
				commit('setAlert', {
					state: true, 
					message: 'Error: La cantidad debe ser mayor a 0',
					class: 'toast-danger'
				});	
			}
		},

		async searchSalesProduct({ state, commit, dispatch }, data) {
			commit('setLoad');
			let req = await fetch(`${api}/Routes/requests.php?op=get_sales_product&id=${data.id}`, {
				method: 'GET',
				mode: 'cors',
			});

			req = await req.json();

			commit('setLoad');

			if(req.state == 'OK') {
				commit('setUpdate', true);
			} else {
				commit('setUpdate', false);
			}
		},

		async searchProducts({ state, commit }) {
			commit('setLoad')

			let req = await fetch(`${api}/Routes/requests.php?op=get_products`, {
				method: 'GET',
				mode: 'cors',
			});

			req = await req.json();

			commit('setLoad');

			if(req.state == 'OK') {
				commit('setProducts', req.payload);
			} else {
				commit('setAlert', {
					state: true, 
					message: 'No hay productos existentes',
					class: 'toast-danger'
				});	
			}
		},

		async searchStocksProducts({ state, commit }) {
			commit('setLoad')

			let req = await fetch(`${api}/Routes/requests.php?op=get_stocks_products`, {
				method: 'GET',
				mode: 'cors',
			});

			req = await req.json();

			commit('setLoad');

			if(req.state == 'OK') {
				commit('setStocksProducts', req.payload);
			} else {
				commit('setAlert', {
					state: true, 
					message: 'No hay productos existentes',
					class: 'toast-danger'
				});	
			}
		},

		async updateProduct({ state, commit, dispatch }, product) {
			commit('setLoad')

			let req = await fetch(`${api}/Routes/requests.php`, {
				method: 'PUT',
				mode: 'cors',
				body: JSON.stringify(product)
			});

			req = await req.json();

			commit('setLoad');

			if(req.state == 'OK') {
				commit('setAlert', {
					state: true, 
					message: 'El producto fue actualizado exitosamente',
					class: 'toast-success',
				});
				commit('setFlag');
			} else {
				commit('setAlert', {
					state: true, 
					message: 'No se pudo actualizar el producto',
					class: 'toast-danger',
				})
				commit('setFlag');
				dispatch("searchProducts")
			}
		},

		async updateSale({ state, commit, dispatch }, data) {
			let stock = +data.product.stock - +data.sale.quantity
			if(stock >= 0) {
				commit('setLoad')

				data.sale.op = "update_sale"
				let req = await fetch(`${api}/Routes/requests.php`, {
					method: 'PUT',
					mode: 'cors',
					body: JSON.stringify(data.sale)
				});

				req = await req.json();

				commit('setLoad');

				if(req.state == 'OK') {
					commit('setAlert', {
						state: true, 
						message: 'La venta se generó exitosamente',
						class: 'toast-success'
					});
				} else {
					commit('setAlert', {
						state: true, 
						message: 'Error: No se pudo realizar la venta',
						class: 'toast-danger'
					});
				}
			} else {
				commit('setAlert', {
					state: true, 
					message: 'Error: No hay inventario disponible para la venta',
					class: 'toast-danger'
				});	
			}

			dispatch("searchStocksProducts")
		},

		async deleteProduct({ state, commit, dispatch }, id) {
			commit('setLoad')

			let req = await fetch(`${api}/Routes/requests.php?op=get_products`, {
				method: 'DELETE',
				mode: 'cors',
				body: JSON.stringify({ id: id })
			});

			req = await req.json();

			commit('setLoad');

			if(req.state == 'OK') {
				setTimeout(() => {
					commit('setAlert', {
						state: true, 
						message: 'El producto fue eliminado exitosamente',
						class: 'toast-success'
					});
				}, 5000)
				commit('setFlag');
				dispatch("searchProducts")
			} else {
				setTimeout(() => {
					commit('setAlert', {
						state: true, 
						message: 'No se pudo eliminar el producto',
						class: 'toast-danger'
					})
				}, 5000)
				commit('setFlag');
				dispatch("searchProducts")
			}
		}
	},

	getters: {
		getProducts: (state) => (item) => {
			let products = state.stocksProducts

			if(item == 'stock') {
				products = products.sort((a, b) => {
					if(a.stock < b.stock) {
						return 1;
					} else {
						return -1;
					}
				})[0]
				
				return products
			} else {
				products = products.sort((a, b) => {
					if(+a.quantity < +b.quantity) {
						return 1;
					} else {
						return -1;
					}
				})[0]

				return products
			}
		}
	}
});

export default store;

La presente prueba necesita para su instalacion, estar ubicada en la ruta de htdocs, y ser ejecutada desde
la carpeta inventario. Además deben de descargarse las siguientes carpetas para su funcionamiento:
- vue
- fontawesome
- moment
La base de datos exportado desde phpMyAdmin, debe ser importada de igual manera, o en su defecto ser copiada y
pegada en la consola SQL con el SGBD Mysql y ejecutarlo.